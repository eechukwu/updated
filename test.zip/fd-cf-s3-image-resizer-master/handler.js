'use strict';

const queryStringHelper = require('querystring');
const sharp = require('sharp');
const AWS = require('aws-sdk');
const S3 = new AWS.S3({
    signatureVersion: 'v4',
});

const BODY_ENCODING = 'base64';
const WIDTH_NAME = 'maxWidth';
const HEIGHT_NAME = 'maxHeight';
const DEFAULT_WIDTH = 440;
const DEFAULT_HEIGHT = 440;

// Restrict available sizes 1x, 2x, 5x, 10x
const SIZES = new Set([44,88,220,440]);

function resize(event, context, callback) {
    const request = event.Records[0].cf.request;
    const bucketPath = request.origin.s3.path;

    let bucket = getBucketNameFromDomainName(request.origin.s3.domainName);
    let [width, height] = getDimensions(request.querystring);

    if (width == null || height == null || width !== height) {
        failedResponse(callback, null, '403');
    }
    else {
        const key = (bucketPath + request.uri).replace(/^\/+/g, '');
        const params = {Bucket: bucket, Key: key};

        S3.getObject(params, function (err, data) {
            if (err) {
                failedResponse(callback, err,'404');
            }
            else {
                resizeS3Image(request.httpVersion, data, width, height, callback);
            }
        });
    }
}

function getBucketNameFromDomainName(domainName) {
    if (domainName == null || domainName.length < 1) {
        return null;
    }
    let parts = domainName.match(/^(.*)\.s3\.amazonaws\.com$/);
    if (parts == null || parts[1] == null || parts[1].length < 1) {
        return null;
    }
    return parts[1];
}

function getDimensions(queryString) {
    let width = DEFAULT_WIDTH;
    let height = DEFAULT_HEIGHT;

    if (queryString) {
        let queryStringsMap = queryStringHelper.parse(queryString);

        if (isNumber(queryStringsMap[WIDTH_NAME])) {
            width = parseInt(queryStringsMap[WIDTH_NAME]);
            width = SIZES.has(width) ? width : null;
        }
        else {
            width = null;
        }
        if (isNumber(queryStringsMap[HEIGHT_NAME])) {
            height = parseInt(queryStringsMap[HEIGHT_NAME]);
            height = SIZES.has(height) ? height : null;
        }
        else {
            height = null;
        }
    }
    return [width, height];
}

function isNumber(input) {
    return input != null && input.length > 0 && !isNaN(input);
}

function createResponse(response, httpVersion, contentType, body, bodyEncoding) {
    if (httpVersion) {
        response.httpVersion = httpVersion;
    }
    if (contentType) {
        response.headers = {
            'content-type': [{'key': 'Content-Type', 'value': contentType}]
        };
    }
    if (body) {
        response.body = body;
    }
    if (bodyEncoding) {
        response.bodyEncoding = bodyEncoding;
    }
    return response;
}

function failedResponse(callback, err, status) {
    if (err) {
        console.log(err, err.stack);
    }
    callback(null, {status: status});
}

function successfulResponse(callback, httpVersion, contentType, body, bodyEncoding) {
    callback(null, createResponse({status: '200',}, httpVersion, contentType, body, bodyEncoding));
}

function resizeS3Image(httpVersion, s3Data, width, height, callback) {
    sharp(s3Data.Body).resize({
        height: height,
        width: width,
        fit: 'inside',
    }).toBuffer(function (err, data, info) {
        if (err) {
            failedResponse(callback, err, '403');
        }
        else {
            let contentType = 'image/' + info.format;
            let body = data.toString(BODY_ENCODING);

            successfulResponse(callback, httpVersion, contentType, body, BODY_ENCODING);
        }
    });
}

module.exports = {
    getDimensions,
    getBucketNameFromDomainName,
    failedResponse,
    successfulResponse,
    createResponse,
    resizeS3Image,
    resize
};


