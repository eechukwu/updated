# NodeJS AWS CloudFront Lambda@Edge Image Resizer

This is a service for serving, and caching - resized images through
CloudFront, originally stored in S3.

## Overview

This makes use of AWS Lambda@Edge. A Lambda function is triggered by a
CloudFront (CDN) origin request. The Lambda then loads the requested
image from S3, resizes the image based on the request, and then
returns the newly sized image to CloudFront for caching and to be
served back in the response to the client. This allows good quality
source/origin images to be resized as required and cached long term in
the CDN, only being resized again when different dimensions are
requested, or the cached image expires.

The service is set up using the [Serverless](https://serverless.com/)
framework, and the Lambda is written using Node.js 6.10. The Serverless
framework is used to define a CloudFormation stack, allowing the
creation of the Lambda Function, the CloudFront distribution, and link
between them.

Note: Lambda@Edge is not yet fully supported by Serverless, as such,
plugins can be used to set up the correct Lambda trigger.

[Sharp](http://sharp.pixelplumbing.com/en/stable/) is used for image
processing, and as this requires compilation of its own dependencies,
a Docker container is used to ensure any compiled code is compatable
with the Lambda's runtime environment.

## Setup

###Branching
A strict branching approach should be followed here to ensure that all environments are up to date.

Feature Branches should be created off the base of the branch `devstack` and use a PR to be merged into.

Merging to `devstack` will deploy the code to the common devstack lambda in use in the testing environment.

From the branch `devstack` create a PR to merge into `perftest`, on merge the performance testing environment lambda will be updated.

From the branch 'perftest' create a PR to merge into `master`, on merge the production environment lambda will be updated.

Therefore the branch strategy should follow:

`Feature Branch` -> `devstack` -> `perftest` -> `master`

### Installation

Check requirements:

```
make requirements
```

This will:
  * Check for the [Docker](https://docs.docker.com/engine/installation) executable to build a local image from the included Dockerfile
  * Check for the [Git](https://git-scm.com/) executable, used to perform repository operations
  * Check for the [AWS-CLI](https://aws.amazon.com/cli), which is used to pass temporary credentials to the Docker deployment image
  * Check for the [`jq`](https://stedolan.github.io/jq/) tool, used for parsing JSON responses from things like AWS-CLI

Due to the differences in installation of these tools across platforms, most of these tools should be installed and be made executable by the user.

Other things that may be of interest are:
  * Node.js
  * The Serverless framework and bail out if it can't be found (install instructions [here](https://serverless.com/framework/docs/providers/aws/guide/installation/)
  * The Serverless framework plugin, [serverless-plugin-cloudfront-lambda-edge](https://github.com/silvermine/serverless-plugin-cloudfront-lambda-edge)
  * The Serverless framework plugin, [serverless-lambda-version](https://github.com/iDVB/serverless-lambda-version)

However, these will be installed within the Docker container, so there is no requirement to install them locally.

### Configuration

The `Makefile` included with this project can be used to simplify stack management.

One variable should be defined in your environment:  `STAGE`

  * `STAGE` - Think of this as a "Serverless environment" - and should be unique to you.

If undefined, `STAGE` will default to the value of the `$USER` environment variable (usually `firstnamelastname`)

By defining these variables using `export`, the values that you set will remain active for all subsequently executed subshells:

```
export STAGE=<your_serverless_stage>
```

Once this is set, you can generate some configuration from a base developer config by running:


```
make devconfig
```

This will create an _environment file_ called `environment/<STAGE>.yml`, customised for your Stage.


### Environment variables

Lambda@Edge does not support environment variables.

## Unit tests

TBD

## Integration tests

TBD

## Deploy

### Deploy all functions

Deploy all functions to a stack.  If the stack doesn't exist, it will be created.

```
make deploy
```

This is being developed in the Development account, as such, first obtain credentials and export environment variables using [AWS Switchrole](https://github.com/hybby/aws-switchrole). GEN_AWS_CREDS is currently set to off so the below is not entirly valid yet. 

This, first of all, builds a deployment container image using the enclosed Dockerfile.  Once built, this image is cached until the Dockerfile or supplied version changes.

Following that, credentials are generated from your IAM principal using `aws sts get-session-token` and passed through to an instance of the Docker image you just built.

The deployment container then builds and bundles all code and ships it up to AWS as part of a CloudFormation Template

We perform deployments from Docker containers running Amazon Linux because this ensures that any compiled objects will match the architecture run by AWS Lambda.

### Jenkins Deploy Job
Jenkins Multi Branch Job : https://jenkins.fdbox.net/operations/job/image-resizer

#### Devstack Deploy
Merging to the branch `devstack` will trigger a new deployment via the Jenkins Deploy Job to the development environment.

#### PerfTest Deploy
Merging to the branch `perftest` will trigger a new deployment via the Jenkins Deploy Job to the performance testing environment.

#### Production Deploy
Merging to the branch `master` will trigger a new deployment via the Jenkins Deploy Job to the production environment.



## Invoking Locally

This has not be attempted yet.

### Serverless

The following commands show how to invoke the lambda function on your local machine,
meaning they can be tested without requiring a deployment.

**Configure:**

```
export DEV_STACK_NAME=<your_dev_stack>
make localconfig
```

This will create an `environments/local.yml` file from `environments/local_base.yml`, customising it for your DevStack name.

The `environments/local.yml` is `.gitignore`'d so that details of your stack are not commited to source control.

### Tearing down a stack
If you're finished with a stack and want to remove it and delete your config, run the following:

```
make remove
```
