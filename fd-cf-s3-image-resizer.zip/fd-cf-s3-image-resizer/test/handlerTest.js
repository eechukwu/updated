const expect = require('chai').expect;
const handler = require('../handler');

const JSON_INPUT_INVALID_DIMS = {
    "Records": [
        {
            "cf": {
                "request": {
                    "origin": {
                        "s3": {
                            "domainName": "fd-dev-lambda-avatar.s3.amazonaws.com",
                            "path": "/original"
                        }
                    },
                    "querystring": "maxWidth=abc&maxHeight=def",
                    "uri": "/lfc.jpg"
                }
            }
        }
    ]
};

const DEFAULT_SIZE = 440;

describe('getDimensions() Default values', function () {
    it('default values should be 440', function () {

        // 1. ARRANGE
        const expectedWidth = DEFAULT_SIZE;
        const expectedHeight = DEFAULT_SIZE;

        // 2. ACT
        let [width, height] = handler.getDimensions("");

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getDimensions() null input', function () {
    it('null querystring should match default size, 440', function () {

        // 1. ARRANGE
        const expectedWidth = DEFAULT_SIZE;
        const expectedHeight = DEFAULT_SIZE;

        // 2. ACT
        let [width, height] = handler.getDimensions(null);

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getDimensions() Valid values supplied', function () {
    it('valid values should match', function () {

        // 1. ARRANGE
        const expectedWidth = 44;
        const expectedHeight = 44;
        const input = "maxWidth=44&maxHeight=44";

        // 2. ACT
        let [width, height] = handler.getDimensions(input);

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getDimensions() Valid values supplied reversed inputs', function () {
    it('valid values should match closest (smaller) availble size, 44', function () {

        // 1. ARRANGE
        const expectedWidth = 44;
        const expectedHeight = 44;
        const input = "maxHeight=44&maxWidth=44";

        // 2. ACT
        let [width, height] = handler.getDimensions(input);

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getDimensions() Invalid value for height supplied', function () {
    it('invalid values should be null', function () {

        // 1. ARRANGE
        const expectedWidth = 44;
        const expectedHeight = null;
        const input = "maxHeight=123&maxWidth=44";

        // 2. ACT
        let [width, height] = handler.getDimensions(input);

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getDimensions() Invalid value for width supplied', function () {
    it('invalid values should be null', function () {

        // 1. ARRANGE
        const expectedWidth = null;
        const expectedHeight = 44;
        const input = "maxHeight=44&maxWidth=abc";

        // 2. ACT
        let [width, height] = handler.getDimensions(input);

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getDimensions() null values', function () {
    it('null values should be null', function () {

        // 1. ARRANGE
        const expectedWidth = null;
        const expectedHeight = null;
        const input = "maxHeight=&maxWidth=";

        // 2. ACT
        let [width, height] = handler.getDimensions(input);

        // 3. ASSERT
        expect(width).to.be.equal(expectedWidth);
        expect(height).to.be.equal(expectedHeight);

    });
});

describe('getBucketNameFromDomainName() null input', function () {
    it('should return default bucket', function () {

        // 1. ARRANGE
        const expectedBucket = null;
        const input = null;

        // 2. ACT
        let bucket = handler.getBucketNameFromDomainName(input);

        // 3. ASSERT
        expect(bucket).to.be.equal(expectedBucket);

    });
});

describe('getBucketNameFromDomainName() invalid domain', function () {
    it('should return default bucket', function () {

        // 1. ARRANGE
        const expectedBucket = null;
        const input = "blahblahblah";

        // 2. ACT
        let bucket = handler.getBucketNameFromDomainName(input);

        // 3. ASSERT
        expect(bucket).to.be.equal(expectedBucket);

    });
});

describe('getBucketNameFromDomainName() valid domain', function () {
    it('should return default bucket', function () {

        // 1. ARRANGE
        const expectedBucket = "mySuperTopSecretBucket";
        const input = expectedBucket+".s3.amazonaws.com";

        // 2. ACT
        let bucket = handler.getBucketNameFromDomainName(input);

        // 3. ASSERT
        expect(bucket).to.be.equal(expectedBucket);

    });
});

describe('getBucketNameFromDomainName() non-matching domain', function () {
    it('should return default bucket', function () {

        // 1. ARRANGE
        const expectedBucket = null;
        const input = "mySuperTopSecretBucket.s3.amazoABCnaws.com";

        // 2. ACT
        let bucket = handler.getBucketNameFromDomainName(input);

        // 3. ASSERT
        expect(bucket).to.be.equal(expectedBucket);

    });
});

describe('createResponse() null inputs', function () {
    it('should match inputs', function () {

        // 1. ARRANGE
        let expectedResponse = null;

        // 2. ACT
        let response = handler.createResponse(null, null, null, null, null);

        // 3. ASSERT
        expect(response).to.be.equal(expectedResponse);

    });
});

describe('createResponse() status only', function () {
    it('should match inputs', function () {

        let status = '511';
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
        };

        // 2. ACT
        let response = handler.createResponse({status: status,}, null, null, null, null);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);
        expect(response.httpVersion).to.be.equal(expectedResponse.httpVersion);
        expect(response.headers).to.be.equal(expectedResponse.headers);
        expect(response.body).to.be.equal(expectedResponse.body);
        expect(response.bodyEncoding).to.be.equal(expectedResponse.bodyEncoding);

    });
});

describe('createResponse() status & httpVersion', function () {
    it('should match inputs', function () {

        let status = '511';
        let httpVersion = 'version!';
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
            httpVersion: httpVersion,
        };

        // 2. ACT
        let response = handler.createResponse({status: status,}, httpVersion, null, null, null);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);
        expect(response.httpVersion).to.be.equal(expectedResponse.httpVersion);
        expect(response.headers).to.be.equal(expectedResponse.headers);
        expect(response.body).to.be.equal(expectedResponse.body);
        expect(response.bodyEncoding).to.be.equal(expectedResponse.bodyEncoding);

    });
});

describe('createResponse() status httpVersion, headers', function () {
    it('should match inputs', function () {

        let status = '511';
        let httpVersion = 'version!';
        let contentType = 'Type';
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
            httpVersion: httpVersion,
            headers: {
                'content-type': [{'key': 'Content-Type', 'value': contentType}]
            },
        };

        // 2. ACT
        let response = handler.createResponse({status: status,}, httpVersion, contentType, null, null);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);
        expect(response.httpVersion).to.be.equal(expectedResponse.httpVersion);
        expect(response.headers["content-type"][0]["value"]).to.be.equal(expectedResponse.headers["content-type"][0]["value"]);
        expect(response.body).to.be.equal(expectedResponse.body);
        expect(response.bodyEncoding).to.be.equal(expectedResponse.bodyEncoding);

    });
});

describe('createResponse() status httpVersion, headers, body', function () {
    it('should match inputs', function () {

        let status = '511';
        let httpVersion = 'version!';
        let contentType = 'Type';
        let body = "body!";
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
            httpVersion: httpVersion,
            headers: {
                'content-type': [{'key': 'Content-Type', 'value': contentType}]
            },
            body: body,
        };

        // 2. ACT
        let response = handler.createResponse({status: status,}, httpVersion, contentType, body, null);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);
        expect(response.httpVersion).to.be.equal(expectedResponse.httpVersion);
        expect(response.headers["content-type"][0]["value"]).to.be.equal(expectedResponse.headers["content-type"][0]["value"]);
        expect(response.body).to.be.equal(expectedResponse.body);
        expect(response.bodyEncoding).to.be.equal(expectedResponse.bodyEncoding);

    });
});

describe('createResponse() status httpVersion, headers, body and bodyEncoding', function () {
    it('should match inputs', function () {

        let status = '511';
        let httpVersion = 'version!';
        let contentType = 'Type';
        let body = "body!";
        let bodyEncoding = "ENCODE";
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
            httpVersion: httpVersion,
            headers: {
                'content-type': [{'key': 'Content-Type', 'value': contentType}]
            },
            body: body,
            bodyEncoding: bodyEncoding
        };

        // 2. ACT
        let response = handler.createResponse({status: status,}, httpVersion, contentType, body, bodyEncoding);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);
        expect(response.httpVersion).to.be.equal(expectedResponse.httpVersion);
        expect(response.headers["content-type"][0]["value"]).to.be.equal(expectedResponse.headers["content-type"][0]["value"]);
        expect(response.body).to.be.equal(expectedResponse.body);
        expect(response.bodyEncoding).to.be.equal(expectedResponse.bodyEncoding);

    });
});

describe('failedResponse()', function () {
    it(' status of 403 expected', function () {
        let status = '403';
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
        };
        let response = {};
        // 2. ACT
        handler.failedResponse((a, b) => {
            response = b;
            return response
        }, null, status);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);

    });
});

describe('successfulResponse()', function () {
    it(' status of 200 expected', function () {
        let status = '200';
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
        };
        let response = {};
        // 2. ACT
        handler.successfulResponse((a, b) => {
            response = b;
            return response
        }, null, null, null, null);

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);

    });
});

describe('resize() invalid width and height', function () {
    it('status of 403 expected', function () {
        let status = '403';
        // 1. ARRANGE
        let expectedResponse = {
            status: status,
        };
        let response = {};
        // 2. ACT
        handler.resize( JSON_INPUT_INVALID_DIMS, null, (a, b) => {
            response = b;
            return response
        });

        // 3. ASSERT
        expect(response.status).to.be.equal(expectedResponse.status);

    });
});
